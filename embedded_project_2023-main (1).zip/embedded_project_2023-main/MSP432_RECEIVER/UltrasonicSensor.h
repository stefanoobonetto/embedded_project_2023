/*
 * UltrasonicSensor.h
 *
 *  Created on: 30 gen 2023
 *      Author: simoneroman
 */

#ifndef ULTRASONICSENSOR_H_
#define ULTRASONICSENSOR_H_

void configUltraSonic();

uint32_t leggiDati();


#endif /* ULTRASONICSENSOR_H_ */
