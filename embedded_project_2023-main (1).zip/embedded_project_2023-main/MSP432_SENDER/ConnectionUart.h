/*
 * ConnectionUart.h
 *
 *  Created on: 26 gen 2023
 *      Author: simoneroman
 */

#ifndef CONNECTIONUART_H_
#define CONNECTIONUART_H_


void configureUart();
void EUSCIA2_IRQHandler(void);


#endif /* CONNECTIONUART_H_ */
